# Herbalia — starter e-commerce website

This is a responsive Persian RTL storefront prototype with a cinematic botanical look.

## Run locally
Open `index.html` in a modern browser. For best results, use a local static server (for example VS Code Live Server).

## Included
- Responsive landing page and botanical CSS artwork
- Product catalog and category filters
- Cart with quantity controls and local browser persistence
- Demo product admin panel (default password: `herbalia123`)
- JSON product export
- Consultation form and Herbalia social/blog links
- Order handoff to Bale with order text copied to clipboard

## Important production limitations
This is a front-end starter, not a secure production commerce backend:
- Products and cart are stored in the visitor's browser (`localStorage`).
- Admin password is visible in client-side JavaScript and is NOT secure. Do not use it to protect real customer/order data.
- There is no shared database, user authentication, inventory synchronization, shipping calculation, or payment gateway yet.
- Checkout opens the Herbalia Bale channel and copies the order summary; it does not collect payment.
- Product prices for sandalwood and Javi are intentionally left as “استعلام قیمت”; update them in the admin panel when confirmed.

## Publish free
You can deploy the folder to a static host such as GitHub Pages or Netlify. Upload the contents of this folder (not the ZIP itself, unless the host supports ZIP deployment). A free subdomain will be provided by the hosting platform.
For a real store, the next step is to connect a secure backend/database (e.g. Supabase) and an Iranian payment gateway, then replace the demo admin with server-side authentication and protected admin APIs.
